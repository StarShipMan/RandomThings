#pragma once
#ifndef WEATHERSTATION_H
#define WEATHERSTATION_H
#include "WeatherRecord.h"
#include <string>
using namespace std;

class WeatherStation 
{
private:
	string weatherStationName;
	int historySize;
	int goodData;
	bool isDone;
	bool hasInputedData;
	WeatherRecord* historyArray;
	//private methods
	void optionsLoop();
	void input(WeatherRecord* historyArray, int goodData);
	void printCurrent(string weatherStationName, WeatherRecord* historyArray, int goodData);
	void printHistory(string weatherStationName, WeatherRecord* historyArray, int goodData);
public:
	WeatherStation();
	~WeatherStation();
	//getters
	string getWeatherStationName();
	int getHistorySize();
	WeatherRecord* getHistoryArray();
	int getGoodData();
	bool getIsDone();
	bool getHasInputedData();
	//setters
	void setWeatherStationName();
	void setHistorySize();
	void setHistoryArray();
	void setGoodData(int newGoodData);
	void setIsDone(bool newIsDone);
	void setHasInputedData(bool newHasINputedData);
	//public methods
	void runProgram();
};
#endif // !WEATHERSTATION_H

