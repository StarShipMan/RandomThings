#include "WeatherRecord.h"
#include <string>
using namespace std;

WeatherRecord::WeatherRecord() 
{
	//do nothing
};
double WeatherRecord::getTemperature()
{
	return temperature;
}
double WeatherRecord::getWindSpeed()
{
	return windSpeed;
}
string WeatherRecord::getWindDirection()
{
	return windDirection;
}
void WeatherRecord::setTemperature(double newTemperature) 
{
	temperature = newTemperature;
}
void WeatherRecord::setWindSpeed(double newWindSpeed)
{
	windSpeed = newWindSpeed;
}
void WeatherRecord::setWindDirection(string newWindDirection)
{
	windDirection = newWindDirection;
}
