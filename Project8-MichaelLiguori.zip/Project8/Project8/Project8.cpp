/* Project8.cpp : This file contains the 'main' function. Program execution begins and ends there.
Author : Michael Liguori
Title : Project 8
Purpose : To modify project 7 such that a class of weather record is implemented, bonus if the weather sation was also a class.
*/

#include <iostream>
#include <string>
#include "WeatherRecord.h"
#include "WeatherStation.h"
using namespace std;

const int HISTORY_COLUMN_SIZE = 2;

int main()
{
    WeatherStation wS1;
    wS1.runProgram();
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file