#pragma once
#ifndef WEATHERRECORD_H
#define WEATHERRECORD_H
#include<string>
using namespace std;

class WeatherRecord 
{
private:
        double temperature;
        double windSpeed;
        string windDirection;
public:
    WeatherRecord();
    //getters
    double getTemperature();
    double getWindSpeed();
    string getWindDirection();
    //setters
    void setTemperature(double newTemperature);
    void setWindSpeed(double newTWindSpeed);
    void setWindDirection(string newWindDirection);
};
#endif // !WEATHERRECORD_H

