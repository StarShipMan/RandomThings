#include "WeatherStation.h"
#include "WeatherRecord.h"
#include <string>
#include <iostream>
using namespace std;

WeatherStation::WeatherStation()
{
    setWeatherStationName();
    setHistorySize();
    historyArray = new WeatherRecord[historySize];
    goodData = 0;
    isDone = false;
    hasInputedData = false;
};
WeatherStation::~WeatherStation()
{
    delete[] historyArray;
    historyArray = NULL;
}
/*
//getters
string WeatherStation::getWeatherStationName() 
{
    return weatherStationName;
}
int WeatherStation::getHistorySize() 
{
    return historySize;
}
WeatherRecord* WeatherStation::getHistoryArray() 
{
    return historyArray;
}
int WeatherStation::getGoodData() 
{
    return goodData;
}
bool WeatherStation::getIsDone() 
{
    return isDone;
}
bool WeatherStation::getHasInputedData() 
{
    return hasInputedData;
}
//setters
*/void WeatherStation::setWeatherStationName() 
{
    cout << "Please enter the name of the weather station: ";
    getline(cin, weatherStationName);
}
void WeatherStation::setHistorySize() 
{
    cout << "Please enter the amount records of past readings inputted to keep in history: ";
    cin >> historySize;
}
/*
void WeatherStation::setHistoryArray() 
{
    historyArray = new WeatherRecord[historySize];
}
void WeatherStation::setGoodData(int newGoodData);
void WeatherStation::setIsDone(bool newIsDone);
void WeatherStation::setHasInputedData(bool newHasINputedData);
*/
//general methods
void WeatherStation::input(WeatherRecord* historyArray, int goodData)
{
    double input;
    string stringInput;
    cout << "Option 1:" << endl;
    cout << "Please enter the current temperature: ";
    cin >> input;
    historyArray[goodData].setTemperature(input);
    cout << endl;
    cout << "Please enter the current wind speed: ";
    cin >> input;
    historyArray[goodData].setWindSpeed(input);
    cout << endl;
    cout << "Please enter the current wind direction: ";
    cin.ignore(1000, '\n');
    cin.clear();
    getline(cin, stringInput);
    cout << endl;
    historyArray[goodData].setWindDirection(stringInput);
}
void WeatherStation::printCurrent(string weatherStationName, WeatherRecord* historyArray, int goodData)
{
    cout << "Option 2:" << endl;
    cout << "Weather Station Name: " << weatherStationName << endl;
    cout << endl;
    cout << "Current Temperature: " << historyArray[goodData - 1].getTemperature() << endl;
    cout << "Current Wind Speed and Direction: " << historyArray[goodData - 1].getWindSpeed() << ", " << historyArray[goodData - 1].getWindDirection() << endl;
    cout << endl;
}
void WeatherStation::printHistory(string weatherStationName, WeatherRecord* historyArray, int goodData)
{
    cout << "Option 3:" << endl;
    cout << "Weather Station Name: " << weatherStationName << endl;
    cout << endl;
    if (goodData > 1)
        cout << "Last " << goodData << " weather readings from the station: " << endl;
    for (int i = (goodData - 1); i >= 0; i--)
    {
        if (i == 0 && goodData == 1)
        {
            cout << "Only Reading Recorded : " << endl;
        }
        else if (i == (goodData - 1))
        {
            cout << "Record " << (i + 1) << ": (most recent)" << endl;
        }
        else if (i == 0)
        {
            cout << "Record " << (i + 1) << ": (oldest)" << endl;
        }
        else
        {
            cout << "Record " << (i + 1) << ": " << endl;
        }

        cout << "Temperature: " << historyArray[i].getTemperature() << " Wind Speed:  " << historyArray[i].getWindSpeed() << " Direction: " << historyArray[i].getWindDirection() << endl;
        cout << endl;
    }
}
void WeatherStation::optionsLoop() 
{
    while (isDone == false)
    {
        cout << "Option 1: Input values for the current temperature, wind speed, and wind direction." << endl;
        cout << "Option 2: Print out to the console the weather station name along with the current temperature, wind speed, and wind direction." << endl;
        cout << "Option 3: Print out to the console the five most recent values inputed for temperature, wind speed, and wind direction." << endl;
        cout << "Option 4: Quit the program." << endl;
        int option;
        cout << endl;
        cout << "Please enter either 1, 2, 3, or 4 to select the corresponding option. ";
        cin >> option;
        cout << endl;
        if (option == 1)
        {
            if (goodData == historySize)
            {
                goodData--;
                for (int i = 0; i < goodData; i++)
                {
                    historyArray[i].setTemperature(historyArray[i + 1].getTemperature());
                    historyArray[i].setWindSpeed(historyArray[i + 1].getWindSpeed());
                    historyArray[i].setWindDirection(historyArray[i + 1].getWindDirection());
                }
            }
            input(historyArray, goodData);
            goodData++;
            hasInputedData = true;
        }
        else if (option == 2)
        {
            if (hasInputedData)
            {
                printCurrent(weatherStationName, historyArray, goodData);
            }
            else
            {
                cout << "No data to print. Please use option 1 to input data, then option 2 to print the current weather readings. \n";
                cout << endl;
            }
        }
        else if (option == 3)
        {
            if (hasInputedData)
            {
                printHistory(weatherStationName, historyArray, goodData);
            }
            else
            {
                cout << "No data to print. Please use option 1 to input data, then option 3 to print up to the last five weather readings. \n";
                cout << endl;
            }
        }
        else if (option == 4)
        {
            cout << "Thank you and have a good day!";
            isDone = true;
            cout << endl;
        }
        else
        {
            cout << "Please enter a valid option value, such as 1, 2, or 3. \n";
            cout << endl;
        }


    }
}
void WeatherStation::runProgram()
{
    cout << endl;
    cout << "There are four options within this program you can choose from. \n";
    cout << endl;
    optionsLoop();
}